import React  from 'react';
import {Link} from 'react-router-dom';
import Home from "./pages/Home";
//import Card from "./pages/Cards/Card";


function Navbar() {
    return (
<div>
 <nav class="navbar navbar-light bg-light shadow"  >
  <Link className="navbar-brand" to="/">Home</Link>
  <Link className="navbar-brand" to="/SkinCare">SkinCare</Link>
  <Link className="navbar-brand" to="/Body">Body</Link>
  <Link className="navbar-brand" to="/Hair">Hair</Link>
  <Link className="navbar-brand" to="/Fragrance">Fragrance</Link>
  <Link className="navbar-brand" to="/Kits r">Kits </Link>
  <Link className="navbar-brand" to="/Gifts">Gifts</Link>
  <Link className="navbar-brand" to="/Read">Read</Link>
  <Link className="navbar-brand" to="/Stores">Stores</Link>
  <Link className="navbar-brand" to="/Cart">Cart</Link>
  <Link className="navbar-brand" to="/Login">Login</Link>
  </nav>
</div>
    );
}

export default Navbar;
