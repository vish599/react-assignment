import React from 'react'
import gift from '../image/gift.png';
import gift1 from '../CSS/gift1.css';

function Gifts()  {
    return (
        <div>
              <div class="row bg-lightblue ">
  <div class="col-sm-7 ">
      <div className="main">
        <h1 class="card-title ">Aesop</h1>
        </div>
        <div className="content">
        <a  class="btn btn-light">Browse all gifts</a>
        </div>
        
      </div>
  <div class="col-sm-5">
  <img  class= "card-img"  src={gift}  alt="..." /> 
  </div>
</div>
        </div>
    )
}

export default Gifts
