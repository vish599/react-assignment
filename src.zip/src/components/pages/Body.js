import React from 'react'
import hand from '../image/hand.png';

function Body  ()  {
    return (
        <div>
            <div class="row bg-lightblue ">
  <div class="col-sm-7">
        <h1 class="card-title ">Aesop</h1>
        <h1>Gift selection, simplified</h1>
        <p class="card-text">Bring joy to deserving recipients of all stripes with a carefully curated selection of formulations for the skin, body and home</p>
        <a  class="btn btn-light">Browse all gifts</a>
      </div>
  <div class="col-sm-5">
  <img  class= "card-img"  src={hand}  alt="..." /> 
  </div>
</div>
        </div>
    )
}

export default Body;
