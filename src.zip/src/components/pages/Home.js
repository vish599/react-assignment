import React from 'react'
import jg from '../image/jg.jpg';

function Home()  {
    return (
    <div>
 <div class="row bg-lightblue ">
  <div class="col-sm-5  ">
        <h1 class="card-title ">Aesop</h1>
        <h1>Gift selection, simplified</h1>
        <p class="card-text">Bring joy to deserving recipients of all stripes with a carefully curated selection of formulations for the skin, body and home</p>
        <a  class="btn btn-light">Browse all gifts</a>
      </div>
  <div class="col-sm-7">
  <img  class= "card-img"  src={jg}  alt="..." /> 
  </div>
</div>






<div class="row bg-lightblue ">
  <div class="col-sm-7">
  <img  class= "card-img"  src={jg}  alt="..." /> 
  </div>
  <div class="col-sm-5  ">
        <h1 class="card-title ">Aesop</h1>
        <h1>Gift selection, simplified</h1>
        <p class="card-text">Bring joy to deserving recipients of all stripes with a carefully curated selection of formulations for the skin, body and home</p>
        <a  class="btn btn-white">Browse all gifts</a>
      </div>
</div>





<div class="row bg-lightblue ">
  <div class="col-sm-5  ">
        <h1 class="card-title ">Aesop</h1>
        <h1>Gift selection, simplified</h1>
        <p class="card-text">Bring joy to deserving recipients of all stripes with a carefully curated selection of formulations for the skin, body and home</p>
        <a  class="btn btn-light">Browse all gifts</a>
      </div>
  <div class="col-sm-7">
  <img  class= "card-img"  src={jg}  alt="..." /> 
  </div>
</div>





<div class="row bg-lightblue ">
  <div class="col-sm-7">
  <img  class= "card-img"  src={jg}  alt="..." /> 
  </div>
  <div class="col-sm-5  ">
        <h1 class="card-title ">Aesop</h1>
        <h1>Gift selection, simplified</h1>
        <p class="card-text">Bring joy to deserving recipients of all stripes with a carefully curated selection of formulations for the skin, body and home</p>
        <a  class="btn btn-white">Browse all gifts</a>
      </div>
</div>
<div class="container">
  <div class="row">
    <div class="col">
     <h1>Seasonal Gift Kits</h1>
    </div>
    <div class="col">
     <p>Comprising formulations for the skin, body and home, our Gift Kit collection is designed to recognise everyday acts of kindness, and reverberate beyond the first exchange. </p>
    </div>
  </div>
</div>












        </div>
    )
}

export default Home
