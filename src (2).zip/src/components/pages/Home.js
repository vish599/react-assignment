import React from 'react'
import home from '../CSS/home.css'
import Ad1 from '../image/Ad1.png';
import Ad2 from '../image/Ad2.png';
import Ad3 from '../image/Ad3.png';
import Ad4 from '../image/Ad4.png';
import Ad5 from '../image/Ad5.png';
import Ad6 from '../image/Ad6.png';
import Ad7 from '../image/Ad7.png';
import Ad8 from '../image/Ad8.png';
import Ad9 from '../image/Ad9.png';

function Home()  {
    return (
    <div>
      
      <div class="firt">
 <div class="row bg-lightblue ">

  <div class="col-sm-6" >
   
    <div id="card"  >
    <h3>Gift selection simplified</h3><br></br>
        <p class="card-text">Bring joy to deserving recipients of all stripes with a <br></br>
        carefully curated selection of formulations for the skin,<br></br> 
        body and home</p><br></br><br></br>
        
        <h4>
        <a  class="btn btn-light">Browse all gifts</a> 
        </h4>
        

        </div>
        
      </div>
      
     
  <div class="col-sm-6">
  <img  class= "card-img"  src={Ad1}  alt="..." /> 
  </div>
</div>
</div>





<div className="card2">
<div class="row bg-lightblue ">
  <div class="col-sm-7">
  <img  class= "card-img"  src={Ad2}  alt="..." /> 
  </div>
  <div class="col-sm-5  ">
  <div id="card2"  >
    <h3>    
For friendly faces</h3><br></br>

        <p class="card-text">Selections of cherished skin care—some for the<br></br> novice with empty bathroom cabinets, others for the well-<br></br>stocked expert. </p><br></br><br></br>
        
        <h4>
        <a  class="btn btn-light">Browse all gifts</a> 
        </h4>
        

        </div>
      </div>
</div>
</div>



<div class="card3">

<div class="row bg-lightblue ">
  <div class="col-sm-5  ">
    <div id="3">
    <h3>Gift selection simplified</h3><br></br>
        <p class="card-text">Bring joy to deserving recipients of all stripes with a <br></br>
        carefully curated selection of formulations for the skin,<br></br> 
        body and home</p><br></br><br></br>
        
        <h4>
        <a  class="btn btn-light">Browse all gifts</a> 
        </h4>
        

      </div>
      </div>
  <div class="col-sm-7">
  <img  class= "card-img"  src={Ad3}  alt="..." /> 
  </div>
</div>
</div>




<div class="row bg-lightblue ">
  <div class="col-sm-7">
  <img  class= "card-img"  src={Ad4}  alt="..." /> 
  </div>
  <div class="col-sm-5  ">
        <h1 class="card-title ">Aesop</h1>
        <h1>Gift selection, simplified</h1>
        <p class="card-text">Bring joy to deserving recipients of all stripes with a carefully curated selection of formulations for the skin, body and home</p>
        <a  class="btn btn-white">Browse all gifts</a>
      </div>
</div>
<div class="container">
  <div class="row">
    <div class="col">
     <h1>Seasonal Gift Kits</h1>
    </div>
    <div class="col">
     <p>Comprising formulations for the skin, body and home, our Gift Kit collection is designed to recognise everyday acts of kindness, and reverberate beyond the first exchange. </p>
    </div>
  </div>
</div>












        </div>
    )
}

export default Home
